package com.tecnotree.automatiom.routers;

public class SFTP_Info {
	
	public  static final String sftpHost_10_4_3_95 = "10.4.3.95";
	public  static final int sftpPort_22 = 22;
	public  static final String sftpUserName_10_4_3_95_22 = "tecnotree";
	public  static final String sftpPassword10_4_3_95_22 = "tecnotree";
	public  static final String sshKey_10_4_3_95 = "10.4.3.95 ssh-rsa AAAAB3NzaC1yc2EAAAABIwAAAQEAnbaHlbTmBEqzoAGSMQQfBFm7NKYmhyPBPhLGoeHT0t88et9uPbV8lBMMV6+NbzmgwXp+eINNofEG8fYhowJY6EqP3Dy9oBgwhFzxoEMVpFOujuw9rjRHpW4zrqxo0q+cAN5DHNiqXPxLmqF5sEKBMge/9djGHlxfbNuXEi5uoemExpQ+8yd2H1xuMrVHV245EC/BUZYC2zWmccWV2Phg41in4GaKddyTCFDFAaVziNZAMn1RuKMG+Xx8N9I2Cji70ZiWOvZiu8iYH/a4ZVxPxo9OyvsQZUiIuAsVfCPomisCmgTmbZSVivgwC1Q4ZaaBavxt/vv0giZ7yipMzHSOzw==";
	public  static final String sftppath_10_4_3_95 = "/home/tecnotree/bulk-store/";
	
	public static final String sftp_Host_172_20_21_57 = "172.20.21.57";
	public static final int sftp_Port_31703 = 31703;
	public static final String sftpUserName = "admin";
	public static final String sftpPasswordName = "admin";
	public static final String sshKey_172_20_21_57= "172.20.21.57 ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAACAQCfeK+wXukXepUaNZmSTGEjDeUTmJdJlMepkUZA6m5p6tzJa77dIAEx1DOdS+uYCOQWJeguACk204p8Qg83w2Is/YtfzoprK9suIBuZLgDoFT+rSXWptVR3weHQqmwh9aN3AwcRN2ql+czgT3SjIMOahz9peLeRKe+20TiOLv8+c0h8+IQxkqX7qrY0sYrrZyJsQ9HQVrLGEb9RLmOgyKPnqCDIRFH72+nYSpcN+k7Yxc8GiL+qUtKs/GZwBYW2oQMVJR/7XeFVfMYgKBbh/R4L9hYztJX5jCn6iovAwhMB9bd0KqDHhJsiU39R8JoUeGXkW83j3/dZdO1QvTY+AQHmZRW7mZ5MInWeT6BwAJqYICfibSfD/0FYXG7fonPAlzAl6lDiMyBpmZnZOMn0vF8JgHPu1AUxgPrcbNbLhwl19qfz2GnIHoDfg2h8IPXhASh56oIGFSbREIeTYjx0JkJgkZsbGKMYKnEjbSApMUNfhUu16/khm+/tptDqmMDnYmU2E4SQ+Jici9FD1bGO2pDUS2Z6NQz5HyzQyhHPnSH/eQnowRc+YnXa15npey/EEsKE/NGEtS/xk1DXsqEk30wMZYEfwEga5YDCCwIEgzYpHIgF2MmCGYnb/AgtjPRQEYvAWz42S2yD1FNnmsxGxTvOfg60+PuzJW5l2l6zrzvPxw==";
	public  static final String sftppath = "/bulk-store/Automation_dont_delete..!/";
	
	public  static final String sftpHost_172_20_21_227 = "172.20.21.227";
	public  static final String sftpUserName_172_20_21_227 = "tecnotree";
	public  static final String sftpPassword_172_20_21_227 = "tecnotree@123";
	public  static final String sshKey_172_20_21_227 = "172.20.21.227 ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQDBOFACNqqkQKK8o4LuaOCiogpO0xwTdFpSqB8394dBJWu0LtrYA9LxjMCwBu7oGB4pcRfLvFBV0g+dVDMuq+2PDkvmyXLntnjZkTLQlH2B2dmxenRfB0QZVEqh86fmrUxbhbI0hDYJLx9YFs49vdYorg7zYOMu2fhnpzFoc8Icw907rJP1PVMQWpK0SeMWYLXhCajWm0oq6GmB0Gf0qwb+1SzaHmFyuhTd5jdK6Yk25rTR67R5WT5ElNW2ZoyI2kK/ILBKyvS1DyuhiHm/UJ4AHkA6DKLjfSPgE2JgOHZQ01+EeYYghyjbzeyv+fOehhajE6kqAYjGakrMB4FmGeY/wXgSmaUpNms3phBDNsgEwOi+UinfYxrauhNDWDMZWw/Fl0Lw17rUyczf8I5wwxvAffMUvaFwMVnR5Z3bkb7+iTPxpvRWmQfrlyhU9J+8tM9vUBWLxeg0dIRuWC1TJnh4vG4EHasDa17UFpsdC+vRluYfFeciHHMFKKHXQwJD860=";
	public  static final String sftppath_172_20_21_227 = "/home/tecnotree/BulkStorage/";
	
	public  static final String file = "[.gz]";
	
	


	

}
