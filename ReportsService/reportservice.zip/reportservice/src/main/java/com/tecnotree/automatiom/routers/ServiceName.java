package com.tecnotree.automatiom.routers;

public class ServiceName {
	
	public static final String FileUploadSftp="FileUploadSftp";	
	public static final String 	localHost22="localHost22";	
	public static final String 	localHost_22="localhost 22";
}
