package com.tecnotree.automatiom.routers;

public enum ValidatorOperation {
	KEY_PRESENTS, EQUALS, HAS_ALL, NOT_EQUALS, NOT_NULL, HAS_STRING, SIZE, EMPTY, NOT_EMPTY
}
